#pragma once

#include <string>

std::string generateRandomAlphaNumeric();
void animateConsoleTitle();