#pragma once

#ifdef _WIN32
#include <windows.h>
#endif

bool isDebuggerPresent();

