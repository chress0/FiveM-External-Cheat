#pragma once

#include <vector>
#include <string>

std::string generateRandomName(const std::vector<std::string>& possibleNames);
void renameFile();
